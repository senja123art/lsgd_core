<?php
    require_once 'config.php';
    include $dir.'/incl/lib/connection.php';

    if(isset($_COOKIE['server'])){
        $cookie = unserialize($_COOKIE['server']);
        $accountID = $cookie['accountID'];
        $password = $cookie['password'];
        $query = $db->prepare("SELECT count(*) FROM accounts WHERE accountID = :accountID");
        $query->execute([':accountID' => $accountID]);
        if($query->fetchColumn() > 0){
            $query = $db->prepare("SELECT userName, password, isAdmin, balance FROM accounts WHERE accountID = :accountID");
            $query->execute([':accountID' => $accountID]);
            $query = $query->fetchAll();
            $account = $query[0];
            if(password_verify($password, $account['password'])){
                $query = $db->prepare("SELECT roles.toolSuggestlist FROM roles INNER JOIN roleassign ON roles.roleID = roleassign.roleID WHERE roleassign.accountID = :accountID");
                $query->execute([':accountID' => $accountID]);
                if($query->fetchColumn() == 1){
                    if(!empty($_GET['id']) OR !empty($_GET['type'])){
                        if(!empty($_GET['id'])){
                            $id = htmlspecialchars($_GET['id']);
                            $query = $db->prepare("SELECT count(*) FROM levels WHERE levelID = :levelID");
                            $query->execute([':levelID' => $id]);
                            if($query->fetchColumn() > 0){
                                $query = $db->prepare("SELECT rated FROM suggestlevels WHERE levelID = :levelID");
                                $query->execute([':levelID' => $id]);
                                if($query->fetchColumn() == 0){
                                    $query = $db->prepare("SELECT levelName, userName, extID, levelLength, starDifficulty, starAuto, starDemon, starDemonDiff, starStars, coins, downloads, likes FROM levels WHERE levelID = :levelID");
                                    $query->execute([':levelID' => $id]);
                                    $query = $query->fetchAll(); $levelInfo = $query[0];
                                    if($levelInfo['starDifficulty'] == 10){
                                        $difficulty = 'easy.png';
                                    } elseif($levelInfo['starDifficulty'] == 20){
                                        $difficulty = 'normal.png';
                                    } elseif($levelInfo['starDifficulty'] == 30){
                                        $difficulty = 'hard.png';
                                    } elseif($levelInfo['starDifficulty'] == 40){
                                        $difficulty = 'harder.png';
                                    } elseif($levelInfo['starDifficulty'] == 50){
                                        if($levelInfo['starAuto'] == 1){
                                            $difficulty = 'auto.png';
                                        } elseif($levelInfo['starDemon'] == 1){
                                            if($levelInfo['starDemonDiff'] == 3){
                                                $difficulty = 'easyDemon.png';
                                            } elseif($levelInfo['starDemonDiff'] == 4){
                                                $difficulty = 'mediumDemon.png';
                                            } elseif($levelInfo['starDemonDiff'] == 5){
                                                $difficulty = 'insaneDemon.png';
                                            } elseif($levelInfo['starDemonDiff'] == 6){
                                                $difficulty = 'extremeDemon.png';
                                            } else {
                                                $difficulty = 'hardDemon.png';
                                            }
                                        } else {
                                            $difficulty = 'insane.png';
                                        }
                                    } else {
                                        $difficulty = 'na.png';
                                    }
                                    $query = $db->prepare("SELECT * FROM suggest WHERE suggestLevelId = :levelID");
                                    $query->execute([':levelID' => $id]); $suggests = $query->fetchAll();
                                } else {
                                    header ('Location: /');
                                }
                            } else {
                                header ('Location: /');
                            }
                        }

                        if(!empty($_GET['type'])){
                            $type = htmlspecialchars($_GET['type']);
                            if($type == 'confirm'){
                                if($_POST['length'] >= 0){
                                    $id = $_POST['id'];
                                    $stars = $_POST['stars'];
                                    if($stars >= 1 AND $stars <= 10){
                                        $auto = 0; $demon = 0;
                                        if($stars == 1 OR $stars >= 8){
                                            $rateDiff = 50;
                                            if($stars == 1){
                                                $auto = 1;
                                            } elseif($stars == 10){
                                                $demon = 1;
                                            }
                                        } elseif($stars == 2){
                                            $rateDiff = 10;
                                        } elseif($stars == 3){
                                            $rateDiff = 20;
                                        } elseif($stars == 4 OR $stars == 5){
                                            $rateDiff = 30;
                                        } elseif($stars == 6 OR $stars == 7){
                                            $rateDiff = 40;
                                        } else {
                                            $rateDiff = 0;
                                            header ('Location: /');
                                        }
                                        $featured = 0; $epic = 0;
                                        if($_POST['featured'] == 'on'){
                                            $featured = 1;
                                            if($_POST['epic'] == 'on'){
                                                $epic = 1;
                                            }
                                        }
                                        $query = $db->prepare("UPDATE levels SET starDifficulty = :difficulty, starStars = :stars, starAuto = :auto, starDemon = :demon, starFeatured = :featured, starEpic = :epic, starCoins = 1 WHERE levelID = :levelID");
                                        $query->execute([':difficulty' => $rateDiff, ':stars' => $stars, ':auto' => $auto, ':demon' => $demon, ':featured' => $featured, ':epic' => $epic, ':levelID' => $id]);
                                        $query = $db->prepare("UPDATE suggestlevels SET rated = 1 WHERE levelID = :levelID");
                                        $query->execute([':levelID' => $id]);
                                        header ('Location: ../sendLevels');
                                    } else {
                                        header ('Location: /');
                                    }
                                } else {
                                    header ('Location: /');
                                }
                            } elseif($type == 'decline'){
                                if(!empty($_GET['id'])){
                                    $id = htmlspecialchars($_GET['id']);
                                    $query = $db->prepare("UPDATE suggestlevels SET rated = -1 WHERE levelID = :levelID");
                                    $query->execute([':levelID' => $id]);
                                    header ('Location: sendLevels');
                                } else {
                                    header ('Location: /');
                                }
                            } else {
                                header ('Location: /');
                            }
                        }
                    } else {
                        header ('Location: /');
                    }
                } else {
                    header ('Location: /');
                }
            } else {
                setcookie('server', null, time(), '/');
                header ('Location: /');
            }
        } else{
            setcookie('server', null, time(), '/');
            header ('Location: /');
        }
    } else { 
        header ('Location: /'); 
    }
?>

<!DOCTYPE html>
<html lang="ru">
    <head>
        <meta charset="UTF-8">
        <title>LSGD • Rate level</title>
        <link rel="stylesheet" href="../css/rateLevel.css?<? include 'version.txt'; ?>">
        <link rel="shortcut icon" href="../img/favicon.ico?v=1" type="image/x-icon">
    </head>
    <body>
        <div class="header">
            <div class="inner-header flexRow">
                <div class="logo"><a href="/">LSGD</a></div>
                <div class="user flexRow flexCenter">
                    <div class="inner-user flexRow flexCenter padding" id="userName"><a href="../account/id<? echo $accountID; ?>"><? echo $account['userName']; ?></a></div>
                    <div class="inner-user flexRow flexCenter padding" id="userBalance"><? echo $account['balance']; ?>&#8381;</div>
                    <div id="setting"><a href="../account/setting">&#9881;</a></div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="levelInfo">
                <div class="line"></div>
                <div class="inner-levelInfo flexRow flexCenter padding">
                    <img id="difficulty" src="../img/levelIcons/<? echo $difficulty; ?>" alt="<? echo $difficulty; ?>">
                    <div class="levelInfo">
                        <b><? echo $levelInfo['levelName']; ?></b>
                        <p>Автор: <a href="../account/id<? echo $levelInfo['extID']; ?>"><? echo $levelInfo['userName']; ?></a></p>
                    </div>
                    <? $likes = $levelInfo['likes']; ?>
                    <div class="levelStats flexColumn flexCenter">
                        <div class="inner-levelStats flexRow flexCenter">
                            <p><? echo $levelInfo['downloads']; ?></p>
                            <img src="../img/download.png" alt="download.png">
                        </div>
                        <div class="inner-levelStats flexRow flexCenter">
                            <? if($likes >= 0){ ?>
                            <p><? echo $likes; ?></p>
                            <img src="../img/like.png" alt="like.png">
                            <? } else { ?>
                            <p><? $likes = $likes*-1; echo $likes; ?></p>
                            <img src="../img/dislike.png" alt="dislike.png">
                            <? } ?>
                        </div>
                        <div class="inner-levelStats flexRow flexCenter">
                            <?php
                                if($levelInfo['levelLength'] == 0){
                                    $length = 'Tiny';
                                } elseif($levelInfo['levelLength'] == 1){
                                    $length = 'Short';
                                } elseif($levelInfo['levelLength'] == 2){
                                    $length = 'Medium';
                                } elseif($levelInfo['levelLength'] == 3){
                                    $length = 'Long';
                                } elseif($levelInfo['levelLength'] == 4){
                                    $length = 'XL';
                                } else {
                                    $length = 'Unknown';
                                }
                            ?>
                            <p><? echo $length; ?></p>
                            <img src="../img/length.png" alt="length.png">
                        </div>
                    </div>
                </div>
                <div class="rate flexRow flexCenter padding">
                    <form class="flexRow flexCenter" action="../rateLevel/confirm" method="post">
                        <div class="text flexRow">
                            <input type="text" name="id" value="<? echo $id; ?>" hidden>
                            <input type="text" name="length" value="<? echo $levelInfo['levelLength']; ?>" hidden>
                            <img src="../img/stars.png" alt="stars.png">
                            <input class="padding" type="text" name="stars" required>
                            <img src="../img/featured.png" alt="featured.png">
                            <input class="checkbox padding" type="checkbox" name="featured">
                            <img src="../img/epic.png" alt="epic.png">
                            <input class="checkbox padding" type="checkbox" name="epic">
                        </div>
                        <input id="confirm" type="submit" hidden>
                        <label for="confirm"><img id="confirm" src="../img/confirm.png" alt="confirm.png"></label>
                    </form>
                    <a href="../rateLevel.php?type=decline&id=<? echo $id; ?>"><img src="../img/decline.png" alt="decline.png"></a>
                </div>
            </div>
            <? foreach($suggests as $suggest){ 
                $query = $db->prepare("SELECT roleID FROM roleassign WHERE accountID = :accountID");
                $query->execute([':accountID' => $suggest['suggestBy']]); $roleID = $query->fetchColumn();
                $query = $db->prepare("SELECT userName FROM accounts WHERE accountID = :accountID");
                $query->execute([':accountID' => $suggest['suggestBy']]); $suggestName = $query->fetchColumn();
                if($suggest['suggestDifficulty'] == 10){
                    $suggestDiff = 'easy.png';
                } elseif($suggest['suggestDifficulty'] == 20){
                    $suggestDiff = 'normal.png';
                } elseif($suggest['suggestDifficulty'] == 30){
                    $suggestDiff = 'hard.png';
                } elseif($suggest['suggestDifficulty'] == 40){
                    $suggestDiff = 'harder.png';
                } elseif($suggest['suggestDifficulty'] == 50){
                    if($suggest['suggestAuto'] == 1){
                        $suggestDiff = 'auto.png';
                    } elseif($suggest['suggestDemon'] == 1){
                        $suggestDiff = 'hardDemon.png';
                    } else {
                        $suggestDiff = 'insane.png';
                    }
                } else {
                    $suggestDiff = 'na.png';
                }
            ?>
            <div class="suggest">
                <div class="line"></div>
                <div class="inner-suggest flexRow flexCenter padding">
                    <div class="suggestDiff flexColumn flexCenter">
                        <img src="../img/levelIcons/<? echo $suggestDiff; ?>" alt="<? echo $suggestDiff; ?>">
                        <div class="stars flexRow flexCenter">
                            <p><? echo $suggest['suggestStars']; ?></p>
                            <img src="../img/stars.png" alt="stars.png">
                        </div>
                    </div>
                    <div class="suggestInfo">
                        <b>Оценка от <a href="../account/id<? echo $suggest['suggestBy']; ?>"><? echo $suggestName; ?></a></b>
                        <p>Feature: <? echo $suggest['suggestFeatured']; ?></p>
                    </div>
                    <? if($roleID == 1){ ?>
                    <div class="modLevel flexRow flexCenter" style="background: #64e0ff">Owner</div>
                    <? } elseif($roleID == 2){ ?>
                    <div class="modLevel flexRow flexCenter" style="background: #fcff64">Helper</div>
                    <? } elseif($roleID == 3){ ?>
                    <div class="modLevel flexRow flexCenter" style="background: #ff6464">Admin</div>
                    <? } elseif($roleID == 4){ ?>
                    <div class="modLevel flexRow flexCenter" style="background: #6aff64">Moderator</div>
                    <? } elseif($roleID == 5){ ?>
                    <div class="modLevel flexRow flexCenter" style="background: var(--light-grey)">VIP</div>
                    <? } ?>
                </div>
            </div>
            <? } ?>
        </div>
    </body>
</html>
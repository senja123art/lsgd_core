<?php
    require_once 'config.php';
    include $dir.'/incl/lib/connection.php';

    if(isset($_COOKIE['server'])){
        $cookie = unserialize($_COOKIE['server']);
        $accountID = $cookie['accountID'];
        $password = $cookie['password'];
        $query = $db->prepare("SELECT count(*) FROM accounts WHERE accountID = :accountID");
        $query->execute([':accountID' => $accountID]);
        if($query->fetchColumn() > 0){
            $query = $db->prepare("SELECT userName, password, isAdmin, balance FROM accounts WHERE accountID = :accountID");
            $query->execute([':accountID' => $accountID]);
            $query = $query->fetchAll();
            $account = $query[0];
            if(password_verify($password, $account['password'])){
                $log = true;
            } else {
                setcookie('server', null, time(), '/');
                header ('Location: /');
            }
        } else{
            setcookie('server', null, time(), '/');
            header ('Location: /');
        }
    } else { $log = false; }

    $stats = array();
    $query = $db->prepare("SELECT count(*) FROM users"); $query->execute(); $stats['users'] = $query->fetchColumn();
    $query = $db->prepare("SELECT count(*) FROM accounts"); $query->execute(); $stats['accounts'] = $query->fetchColumn();
    $query = $db->prepare("SELECT count(*) FROM levels"); $query->execute(); $stats['levels'] = $query->fetchColumn();
    $query = $db->prepare("SELECT count(*) FROM comments"); $query->execute(); $stats['comments'] = $query->fetchColumn();

    $query = $db->prepare("SELECT title, content, uploadDate FROM news ORDER BY newsID DESC LIMIT 3"); $query->execute(); $news = $query->fetchAll(); $countNews = count($news);
?>

<!DOCTYPE html>
<html lang="ru">
    <head>
        <meta charset="UTF-8">
        <title>LSGD</title>
        <link rel="stylesheet" href="css/index.css?<? include 'version.txt'; ?>">
        <link rel="shortcut icon" href="img/favicon.ico?v=1" type="image/x-icon">
    </head>
    <body>
        <div class="header">
            <div class="inner-header flexRow">
                <div class="logo"><a href="/">LSGD</a></div>
                <div class="user flexRow flexCenter">
                    <? if($log){ ?>
                    <div class="inner-user flexRow flexCenter padding" id="userName"><a href="account/id<? echo $accountID; ?>"><? echo $account['userName']; ?></a></div>
                    <div class="inner-user flexRow flexCenter padding" id="userBalance"><? echo $account['balance']; ?>&#8381;</div>
                    <div id="setting"><a href="account/setting">&#9881;</a></div>
                    <? } else { ?>
                    <a href="auth">Войти</a>
                    <? } ?>
                </div>
            </div>
            <ul class="menu flexRow">
                <li class="flexRow flexCenter">Главная</li>
                <li class="flexRow flexCenter">Новости</li>
                <li class="flexRow flexCenter">Скачать сервер</li>
                <li class="flexRow flexCenter">Информация</li>
                <? if($log){ ?>
                <ul class="otherMenu">
                    <li class="flexRow flexCenter">Дополнительно</li>
                    <a href="topUsers"><li class="flexRow flexCenter">Топ игроков</li></a>
                    <a href="shop"><li class="flexRow flexCenter">Магазин</li></a>
                    <a href="loadMusic"><li class="flexRow flexCenter">Загрузка музыки</li></a>
                    <a href="sendLevels"><li class="flexRow flexCenter">Отправленные уровни</li></a>
                    <? if($account['isAdmin'] == 1){ ?>
                    <a href="addMoney"><li class="flexRow flexCenter">Добавить деньги</li></a>
                    <? } ?>
                </ul>
                <? } ?>
            </ul>
        </div>
        <div class="container">
            <div class="title">
                <div class="line"></div>
                <div class="inner-title flexRow flexCenter padding">
                    <img src="img/logo.png" alt="logo.png">
                    <div id="content">
                        <p><b style="color: var(--white)">LSGD</b> — это приватный сервер игры Geometry Dash, где вы легко сможете получить оценку на уровень, как и попасть в топ 100 игроков. Также на сервере присутствует кастомный текстур пак (заменены некоторые текстурки, а так текстурки из оригинальной игры).</p>
                    </div>
                </div>
            </div>
            <div class="stats flexRow">
                <div class="inner-stats">
                    <div class="line"></div>
                    <div class="statsBlock flexColumn flexCenter padding">
                        <p id="title"><b>Игроки</b></p>
                        <p id="content"><? echo $stats['users']; ?></p>
                    </div>
                </div>
                <div class="inner-stats">
                    <div class="line"></div>
                    <div class="statsBlock flexColumn flexCenter padding">
                        <p id="title"><b>Аккаунты</b></p>
                        <p id="content"><? echo $stats['accounts']; ?></p>
                    </div>
                </div>
                <div class="inner-stats">
                    <div class="line"></div>
                    <div class="statsBlock flexColumn flexCenter padding">
                        <p id="title"><b>Уровни</b></p>
                        <p id="content"><? echo $stats['levels']; ?></p>
                    </div>
                </div>
                <div class="inner-stats">
                    <div class="line"></div>
                    <div class="statsBlock flexColumn flexCenter padding">
                        <p id="title"><b>Комментарии</b></p>
                        <p id="content"><? echo $stats['comments']; ?></p>
                    </div>
                </div>
            </div>
            <? if($countNews > 0){ ?>
            <div class="news flexRow">
                <? foreach($news as $newsBlock){ ?>
                <div class="inner-news">
                    <div class="line"></div>
                    <div class="newsBlock flexColumn padding">
                        <p id="title"><b><? echo $newsBlock['title']; ?></b></p>
                        <p id="content"><? echo $newsBlock['content']; ?></p>
                        <p id="publicDate"><? echo date("d.m.Y", $newsBlock['uploadDate']); ?></p>
                    </div>
                </div>
                <? } ?>
            </div>
            <? } ?>
            <div class="download">
                <div class="line"></div>
                <div class="inner-download flexRow">
                    <div class="downloadBlock flexColumn flexCenter">
                        <p>Скачать сервер</p>
                        <a href="download/lsgd.zip" download><div class="button flexCenter padding" id="windows">Для Windows</div></a>
                        <a href="download/lsgd.apk" download><div class="button flexCenter padding" id="android">Для Android</div></a>
                    </div>
                    <div class="downloadBlock flexColumn flexCenter">
                        <p>Скачать файлы сервера</p>
                        <a href="download/textures.zip" download><div class="button flexCenter padding" id="textures">Текстур пак</div></a>
                    </div>
                </div>
            </div>
            <div class="info">
                <div class="line"></div>
                <div class="inner-info flexRow padding">
                    <div class="infoBlock flexColumn" id="right">
                        <p>Создатель сервера:</p>
                        <p>Владелец сервера:</p>
                        <p>Музыка в меню игры:</p>
                        <p>Музыка в режиме практики:</p>
                        <p style="color: var(--llight-grey)">Создатель сайта:</p>
                    </div>
                    <div class="infoBlock flexColumn" id="left">
                        <p>TopLoox</p>
                        <p>DeXotik</p>
                        <p>Teminite - Unstoppable</p>
                        <p>REZZ & deadmau5 - Hypnocurrency</p>
                        <p style="color: var(--llight-grey)">DeXotik &#169; 2021</p>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<? 
    // error_reporting(0);
    $dir = '../server'; 
?>
<?php
    require_once 'config.php';
    include $dir.'/incl/lib/connection.php';

    if(isset($_GET['id']) OR isset($_GET['type'])){
        if(isset($_COOKIE['server'])){
            $cookie = unserialize($_COOKIE['server']);
            $accountID = $cookie['accountID'];
            $password = $cookie['password'];
            $query = $db->prepare("SELECT count(*) FROM accounts WHERE accountID = :accountID");
            $query->execute([':accountID' => $accountID]);
            if($query->fetchColumn() > 0){
                $query = $db->prepare("SELECT userName, password, isAdmin, balance FROM accounts WHERE accountID = :accountID");
                $query->execute([':accountID' => $accountID]);
                $query = $query->fetchAll();
                $account = $query[0];
                if(password_verify($password, $account['password'])){
                    $log = true;
                } else {
                    setcookie('server', null, time(), '/');
                    header ('Location: /');
                }
            } else{
                setcookie('server', null, time(), '/');
                header ('Location: /');
            }
        } else {
            $log = false; 
        }

        if(!empty($_GET['id'])){
            $id = htmlspecialchars($_GET['id']);
            if($log){
                if($id == $accountID){ $owner = true; } else { $owner = false; }
            } else {
                $owner = false;
            }
        } else {
            $id = $accountID;
            $owner = true;
        }

        if(!empty($_GET['type'])){
            $type = htmlspecialchars($_GET['type']);
            if($type == 'setting' AND $log){
                $query = $db->prepare("SELECT email, registerDate FROM accounts WHERE accountID = :accountID");
                $query->execute([':accountID' => $accountID]);
                $query = $query->fetchAll();
                $accountInfo = $query[0];
            } elseif($type == 'setting' AND !($log)){
                header ('Location: /');
            } elseif($type == 'unauth'){
                setcookie('server', null, time(), '/');
                header ('Location: /');
            } elseif($type == 'changeNickname'){
                $login = $_POST['login'];
                $query = $db->prepare("SELECT password FROM accounts WHERE accountID = :accountID");
                $query->execute([':accountID' => $accountID]);
                $hash = $query->fetchColumn();
                if(password_verify($password, $hash)){
                    $query = $db->prepare("SELECT count(*) FROM accounts WHERE userName = :userName");
                    $query->execute([':userName' => $login]);
                    $query = $query->fetchColumn();
                    if($query == 0){
                        $query = $db->prepare("UPDATE accounts SET userName = :userName WHERE accountID = :accountID");
                        $query->execute([':userName' => $login, ':accountID' => $cookie['accountID']]);
                        $query = $db->prepare("UPDATE users SET userName = :userName WHERE extID = :extID");
                        $query->execute([':userName' => $login, ':extID' => $cookie['accountID']]);
                        setcookie('server', null, time(), '/');
                        header ('Location: /');
                    } else {
                        header ('Location: account/setting');
                    }
                } else {
                    setcookie('server', null, time(), '/');
                    header ('Location: /');
                }
            } elseif($type == 'changePassword'){
                $changePassword = $_POST['password'];
                $confirmPassword = $_POST['confirmPassword'];
                if($changePassword == $confirmPassword){
                    $query = $db->prepare("SELECT password FROM accounts WHERE accountID = :accountID");
                    $query->execute([':accountID' => $accountID]);
                    $hash = $query->fetchColumn();
                    if(password_verify($password, $hash)){
                        $query = $db->prepare("UPDATE accounts SET password = :password WHERE accountID = :accountID");
                        $query->execute([':password' => password_hash($changePassword, PASSWORD_DEFAULT), ':accountID' => $accountID]);
                        setcookie('server', null, time(), '/');
                        header ('Location: /');
                    } else {
                        setcookie('server', null, time(), '/');
                        header ('Location: /');
                    }
                } else {
                    header ('Location: account/setting');
                }
            } else{
                header ('Location: /');
            }
        }

        $query = $db->prepare("SELECT count(*) FROM users WHERE extID = :extID");
        $query->execute([':extID' => $id]);
        if($query->fetchColumn() > 0){
            $query = $db->prepare("SELECT userID, userName, stars, diamonds, coins, userCoins, demons, creatorPoints, lastPlayed FROM users WHERE extID = :extID");
            $query->execute([':extID' => $id]);
            $query = $query->fetchAll();
            $userStats = $query[0];
            $query = $db->prepare("SELECT youtubeurl, twitch, twitter, isAdmin FROM accounts WHERE accountID = :accountID");
            $query->execute([':accountID' => $id]);
            $query = $query->fetchAll();
            $accountStats = $query[0];
            $query = $db->prepare("SELECT roles.modBadgeLevel FROM roles INNER JOIN roleassign ON roles.roleID = roleassign.roleID WHERE roleassign.accountID = :accountID");
            $query->execute([':accountID' => $id]);
            $modBadge = $query->fetchColumn();
            if($accountStats['isAdmin'] == 1){ $modBadge = 3; }
            $query = $db->prepare("SELECT comment, likes FROM acccomments WHERE userID = :userID ORDER BY likes DESC LIMIT 3");
            $query->execute([':userID' => $userStats['userID']]);
            $comments = $query->fetchAll();
            $query = $db->prepare("SELECT person1, person2 FROM friendships WHERE person1 = :accountID OR person2 = :accountID");
            $query->execute([':accountID' => $id]);
            $query = $query->fetchAll();
            $friends = array();
            $friendID = array();
            for($i = 0; $i < count($query); $i++){
                if($query[$i]['person1'] == $id){
                    $friendID[$i] = $query[$i]['person2'];
                } else {
                    $friendID[$i] = $query[$i]['person1'];
                }
            }
            for($i = 0; $i < count($friendID); $i++){
                $query = $db->prepare("SELECT extID, userName, stars FROM users WHERE extID = :extID");
                $query->execute([':extID' => $friendID[$i]]);
                $query = $query->fetchAll();
                $friends[$i] = $query[0];
            }
            usort($friends, function($b, $a){ return $a['stars'] - $b['stars']; });
        } else {
            header ('Location: /');
        }
    } else {
        header ('Location: /');
    }
?>

<!DOCTYPE html>
<html lang="ru">
    <head>
        <meta charset="UTF-8">
        <title>LSGD • Account</title>
        <link rel="stylesheet" href="../css/account.css?<? include 'version.txt'; ?>">
        <link rel="shortcut icon" href="../img/favicon.ico?v=1" type="image/x-icon">
    </head>
    <body>
        <div class="header">
            <div class="inner-header flexRow">
                <div class="logo"><a href="/">LSGD</a></div>
                <div class="user flexRow flexCenter">
                    <? if($log){ ?>
                    <div class="inner-user flexRow flexCenter padding" id="userName"><a href="../account/id<? echo $accountID; ?>"><? echo $account['userName']; ?></a></div>
                    <div class="inner-user flexRow flexCenter padding" id="userBalance"><? echo $account['balance']; ?>&#8381;</div>
                    <div id="setting"><a href="../account/setting">&#9881;</a></div>
                    <? } else { ?>
                    <a href="auth">Войти</a>
                    <? } ?>
                </div>
            </div>
        </div>
        <div class="container flexRow">
            <? if($type == 'setting'){ ?>
            <div class="accountSetting">
                <div class="line"></div>
                <div class="inner-accountSetting flexColumn flexCenter padding">
                    <div class="userName flexRow flexCenter">
                        <? if($modBadge > 0){ ?>
                        <img src="../img/mod-<? echo $modBadge; ?>.png" alt="mod-<? echo $modBadge; ?>.png">
                        <? } ?>
                        <p><? echo $userStats['userName']; ?></p>
                        <? if($owner){ ?>
                        <p class="flexRow" id="setting"><a href="../account/unauth">Выйти</a></p>
                        <? } ?>
                    </div>
                    <div class="accountInfo flexColumn flexCenter">
                        <p>E-mail: <b style="color: var(--white)"><? echo $accountInfo['email']; ?></b></p>
                        <p>Дата регистрации: <b style="color: var(--white)"><? echo date("d.m.Y", $accountInfo['registerDate']); ?></b></p>
                    </div>
                </div>
            </div>
            <div class="change">
                <div class="inner-change">
                    <div class="line"></div>
                    <form class="changeBlock flexColumn flexCenter padding" action="../account.php?type=changeNickname" method="post">
                        <p>Изменить имя профиля</p>
                        <input class="text" type="text" name="login" placeholder="Введите новое имя профиля" required>
                        <input class="button" type="submit" value="Изменить">
                    </form>
                </div>
                <div class="inner-change">
                    <div class="line"></div>
                    <form class="changeBlock flexColumn flexCenter padding" action="../account.php?type=changePassword" method="post">
                        <p>Изменить пароль</p>
                        <input class="text" type="password" name="password" placeholder="Введите новый пароль" required>
                        <input class="text" type="password" name="confirmPassword" placeholder="Подтвердите пароль" required>
                        <input class="button" type="submit" value="Изменить">
                    </form>
                </div>
            </div>
            <? } else { ?>
            <div class="account">
                <div class="line"></div>
                <div class="inner-account flexColumn padding">
                    <div class="userName flexRow flexCenter">
                        <? if($modBadge > 0){ ?>
                        <img src="../img/mod-<? echo $modBadge; ?>.png" alt="mod-<? echo $modBadge; ?>.png">
                        <? } ?>
                        <p><? echo $userStats['userName']; ?></p>
                        <? if($owner){ ?>
                        <p class="flexRow" id="setting"><a href="../account/setting">Настройки</a></p>
                        <? } ?>
                    </div>
                    <div class="stats flexRow">
                        <div class="statsBlock flexColumn flexCenter padding">
                            <img src="../img/stars.png" alt="stars.png">
                            <p><? echo $userStats['stars']; ?></p>
                        </div>
                        <div class="statsBlock flexColumn flexCenter padding">
                            <img src="../img/coins.png" alt="coins.png">
                            <p><? echo $userStats['coins']; ?></p>
                        </div>
                        <div class="statsBlock flexColumn flexCenter padding">
                            <img src="../img/userCoins.png" alt="userCoins.png">
                            <p><? echo $userStats['userCoins']; ?></p>
                        </div>
                    </div>
                    <div class="stats flexRow">
                        <div class="statsBlock flexColumn flexCenter padding">
                            <img src="../img/diamonds.png" alt="diamonds.png">
                            <p><? echo $userStats['diamonds']; ?></p>
                        </div>
                        <div class="statsBlock flexColumn flexCenter padding">
                            <img src="../img/demons.png" alt="demons.png">
                            <p><? echo $userStats['demons']; ?></p>
                        </div>
                        <div class="statsBlock flexColumn flexCenter padding">
                            <img src="../img/creatorPoints.png" alt="creatorPoints.png">
                            <p><? echo $userStats['creatorPoints']; ?></p>
                        </div>
                    </div>
                    <? if($accountStats['youtubeurl'] != '' OR $accountStats['twitch'] != '' OR $accountStats['twitter'] != ''){ ?>
                    <div class="links flexRow flexCenter">
                        <? if($accountStats['youtubeurl'] != ''){ ?>
                        <a href="https://youtube.com/channel/<? echo $accountStats['youtubeurl']; ?>"><img src="../img/youtube.png" alt="youtube.png"></a>
                        <? } if($accountStats['twitch'] != ''){ ?>
                        <a href="https://twitch.tv/<? echo $accountStats['twitch']; ?>"><img src="../img/twitch.png" alt="twitch.png"></a>
                        <? } if($accountStats['twitter'] != ''){ ?>
                        <a href="https://twitter.com/<? echo $accountStats['twitter']; ?>"><img src="../img/twitter.png" alt="twitter.png"></a>
                        <? } ?>
                    </div>
                    <? } ?>
                </div>
            </div>
            <div class="accountStats">
                <div class="line"></div>
                <div class="inner-accountStats flexRow padding">
                    <div class="accountStatsBlock flexColumn" style="min-width: 300px">
                        <p id="title">Лучшие комментарии</p>
                        <? foreach($comments as $comment){ ?>
                        <div class="comment flexRow flexCenter">
                            <p class="flexRow flexCenter padding" id="content"><? echo base64_decode($comment['comment']); ?></p>
                            <div class="likes flexRow flexCenter padding">
                                <p><? echo $comment['likes']; ?></p>
                                <img src="../img/like.png" alt="like.png">
                            </div>
                        </div>
                        <? } ?>
                    </div>
                    <div class="accountStatsBlock flexColumn" style="min-width: 250px">
                        <p id="title">Топ друзей</p>
                        <div class="flexColumn flexCenter">
                            <? foreach($friends as $friend){ ?>
                            <div class="friend flexRow flexCenter">
                                <a href="../account/id<? echo $friend['extID']; ?>"><? echo $friend['userName']; ?></a>
                                <p>- <? echo $friend['stars']; ?></p>
                                <img src="../img/stars.png" alt="stars.png">
                            </div>
                            <? } ?>
                        </div>
                    </div>
                </div>
            </div>
            <? } ?>
        </div>
    </body>
</html>
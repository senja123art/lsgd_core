<?php
    if(isset($_COOKIE['server'])){ header ('Location: /'); }

    require_once 'config.php';
    include $dir.'/incl/lib/connection.php';

    if(isset($_POST['submit'])){
        $login = $_POST['login'];
        $password = $_POST['password'];
        if($login != '' AND $password != ''){
            $query = $db->prepare("SELECT count(*) FROM accounts WHERE userName LIKE :userName");
            $query->execute([':userName' => $login]);
            if($query->fetchColumn() > 0){
                $query = $db->prepare("SELECT accountID, password FROM accounts WHERE userName LIKE :userName");
                $query->execute([':userName' => $login]);
                $query = $query->fetchAll();
                $account = $query[0];
                if(password_verify($password, $account['password'])){
                    $cookie = ['accountID' => $account['accountID'], 'password' => $password];
                    setcookie('server', serialize($cookie), time()+(60*60*24), '/');
                    header ('Location: /');
                } else {
                    header ('Location: auth?err=3');
                }
            } else {
                header ('Location: auth?err=2');
            }
        } else{
            header ('Location: auth?err=1');
        }
    }

    if(isset($_GET['err'])){
        $err = htmlspecialchars($_GET['err']);
        if($err == 1){
            $errText = 'Были отправлены пустые поля';
        } elseif($err == 2){
            $errText = 'Такого аккаунта не существует';
        } elseif($err == 3){
            $errText = 'Неправильный пароль';
        } else {
            $errText = 'Неизвестная ошибка';
        }
        echo '<div class="error">
            <div class="inner-error">
                <p>'.$errText.'</p>
            </div>
        </div>';
    }
?>

<!DOCTYPE html>
<html lang="ru">
    <head>
        <meta charset="UTF-8">
        <title>LSGD • Auth</title>
        <link rel="stylesheet" href="css/auth.css?<? include 'version.txt'; ?>">
        <link rel="shortcut icon" href="img/favicon.ico?v=1" type="image/x-icon">
    </head>
    <body>
        <div class="header flexRow">
            <div class="logo"><a href="/">LSGD</a></div>
        </div>
        <div class="container flexRow flexCenter">
            <div class="auth">
                <div class="line"></div>
                <form class="inner-auth flexColumn flexCenter padding" action="auth.php" method="post">
                    <p>Вход</p>
                    <input class="text" type="text" name="login" placeholder="Введите имя аккаунта" required>
                    <input class="text" type="password" name="password" placeholder="Введите пароль" required>
                    <input class="button" type="submit" name="submit" value="Войти">
                </form>
            </div>
        </div>
    </body>
</html>
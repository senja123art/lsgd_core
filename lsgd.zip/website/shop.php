<?php
    require_once 'config.php';
    include $dir.'/incl/lib/connection.php';

    if(isset($_COOKIE['server'])){
        $cookie = unserialize($_COOKIE['server']);
        $accountID = $cookie['accountID'];
        $password = $cookie['password'];
        $query = $db->prepare("SELECT count(*) FROM accounts WHERE accountID = :accountID");
        $query->execute([':accountID' => $accountID]);
        if($query->fetchColumn() > 0){
            $query = $db->prepare("SELECT userName, password, isAdmin, balance FROM accounts WHERE accountID = :accountID");
            $query->execute([':accountID' => $accountID]);
            $query = $query->fetchAll();
            $account = $query[0];
            if(password_verify($password, $account['password'])){
                $log = true;
            } else {
                setcookie('server', null, time(), '/');
                header ('Location: /');
            }
        } else{
            setcookie('server', null, time(), '/');
            header ('Location: /');
        }

        $query = $db->prepare("SELECT roleID FROM roleassign WHERE accountID = :accountID"); $query->execute([':accountID' => $accountID]); $roleID = $query->fetchColumn();
        $query = $db->prepare("SELECT rolePrice FROM roles WHERE roleID = :roleID"); $query->execute([':roleID' => $roleID]); $rolePrice = $query->fetchColumn();
        $query = $db->prepare("SELECT rolePrice FROM roles WHERE roleID = 5"); $query->execute(); $vipPrice = $query->fetchColumn() - $rolePrice; if($vipPrice < 0) $vipPrice = 0;
        $query = $db->prepare("SELECT rolePrice FROM roles WHERE roleID = 4"); $query->execute(); $moderPrice = $query->fetchColumn() - $rolePrice; if($moderPrice < 0) $moderPrice = 0;
        $query = $db->prepare("SELECT rolePrice FROM roles WHERE roleID = 3"); $query->execute(); $adminPrice = $query->fetchColumn() - $rolePrice; if($adminPrice < 0) $adminPrice = 0;

        if(!empty($_GET['type'])){
            $type = htmlspecialchars($_GET['type']);
            if($type == 'giveVIP'){
                $id = $_POST['id'];
                $query = $db->prepare("SELECT count(*) FROM accounts WHERE accountID = :accountID");
                $query->execute([':accountID' => $id]);
                if($query->fetchColumn() > 0){
                    $query = $db->prepare("SELECT roleID FROM roleassign WHERE accountID = :accountID"); $query->execute([':accountID' => $id]); $roleID = $query->fetchColumn();
                    $query = $db->prepare("SELECT rolePrice FROM roles WHERE roleID = :roleID"); $query->execute([':roleID' => $roleID]); $rolePrice = $query->fetchColumn();
                    $query = $db->prepare("SELECT rolePrice FROM roles WHERE roleID = 5"); $query->execute(); $vipPrice = $query->fetchColumn() - $rolePrice; if($vipPrice < 0) $vipPrice = 0;
                    if($account['balance']-$vipPrice >= 0){
                        $query = $db->prepare("SELECT count(*) FROM roleassign WHERE accountID = :accountID");
                        $query->execute([':accountID' => $id]);
                        if($query->fetchColumn() > 0){
                            if($roleID <= 5){
                                header ('Location: shop');
                            } else {
                                $query = $db->prepare("UPDATE roleassign SET roleID = 5 WHERE accountID = :accountID");
                                $query->execute([':accountID' => $id]);
                                $query = $db->prepare("UPDATE accounts SET balance = :balance WHERE accountID = :accountID");
                                $query->execute([':balance' => $account['balance']-$vipPrice, ':accountID' => $accountID]);
                                header ('Location: shop');
                            }
                        } else {
                            $query = $db->prepare("INSERT INTO roleassign (roleID, accountID) VALUES (5, :accountID)");
                            $query->execute([':accountID' => $id]);
                            $query = $db->prepare("UPDATE accounts SET balance = :balance WHERE accountID = :accountID");
                            $query->execute([':balance' => $account['balance']-$vipPrice, ':accountID' => $accountID]);
                            header ('Location: shop');
                        }
                    } else {
                        header ('Location: shop');
                    }
                } else {
                    header ('Location: shop');
                }
            } elseif($type == 'buyVIP'){
                if($account['balance']-$vipPrice >= 0){
                    $query = $db->prepare("SELECT count(*) FROM roleassign WHERE accountID = :accountID");
                    $query->execute([':accountID' => $accountID]);
                    if($query->fetchColumn() > 0){
                        if($roleID <= 5){
                            header ('Location: shop');
                        } else {
                            $query = $db->prepare("UPDATE roleassign SET roleID = 5 WHERE accountID = :accountID");
                            $query->execute([':accountID' => $accountID]);
                            $query = $db->prepare("UPDATE accounts SET balance = :balance WHERE accountID = :accountID");
                            $query->execute([':balance' => $account['balance']-$vipPrice, ':accountID' => $accountID]);
                            header ('Location: shop');
                        }
                    } else {
                        $query = $db->prepare("INSERT INTO roleassign (roleID, accountID) VALUES (5, :accountID)");
                        $query->execute([':accountID' => $accountID]);
                        $query = $db->prepare("UPDATE accounts SET balance = :balance WHERE accountID = :accountID");
                        $query->execute([':balance' => $account['balance']-$vipPrice, ':accountID' => $accountID]);
                        header ('Location: shop');
                    }
                } else {
                    header ('Location: shop');
                }
            } elseif($type == 'giveModerator'){
                $id = $_POST['id'];
                $query = $db->prepare("SELECT count(*) FROM accounts WHERE accountID = :accountID");
                $query->execute([':accountID' => $id]);
                if($query->fetchColumn() > 0){
                    $query = $db->prepare("SELECT roleID FROM roleassign WHERE accountID = :accountID"); $query->execute([':accountID' => $id]); $roleID = $query->fetchColumn();
                    $query = $db->prepare("SELECT rolePrice FROM roles WHERE roleID = :roleID"); $query->execute([':roleID' => $roleID]); $rolePrice = $query->fetchColumn();
                    $query = $db->prepare("SELECT rolePrice FROM roles WHERE roleID = 4"); $query->execute(); $moderPrice = $query->fetchColumn() - $rolePrice; if($moderPrice < 0) $moderPrice = 0;
                    if($account['balance']-$moderPrice >= 0){
                        $query = $db->prepare("SELECT count(*) FROM roleassign WHERE accountID = :accountID");
                        $query->execute([':accountID' => $id]);
                        if($query->fetchColumn() > 0){
                            if($roleID <= 4){
                                header ('Location: shop');
                            } else {
                                $query = $db->prepare("UPDATE roleassign SET roleID = 4 WHERE accountID = :accountID");
                                $query->execute([':accountID' => $id]);
                                $query = $db->prepare("UPDATE accounts SET balance = :balance WHERE accountID = :accountID");
                                $query->execute([':balance' => $account['balance']-$moderPrice, ':accountID' => $accountID]);
                                header ('Location: shop');
                            }
                        } else {
                            $query = $db->prepare("INSERT INTO roleassign (roleID, accountID) VALUES (4, :accountID)");
                            $query->execute([':accountID' => $id]);
                            $query = $db->prepare("UPDATE accounts SET balance = :balance WHERE accountID = :accountID");
                            $query->execute([':balance' => $account['balance']-$moderPrice, ':accountID' => $accountID]);
                            header ('Location: shop');
                        }
                    } else {
                        header ('Location: shop');
                    }
                } else {
                    header ('Location: shop');
                }
            } elseif($type == 'buyModerator'){
                if($account['balance']-$moderPrice >= 0){
                    $query = $db->prepare("SELECT count(*) FROM roleassign WHERE accountID = :accountID");
                    $query->execute([':accountID' => $accountID]);
                    if($query->fetchColumn() > 0){
                        if($roleID <= 4){
                            header ('Location: shop');
                        } else {
                            $query = $db->prepare("UPDATE roleassign SET roleID = 4 WHERE accountID = :accountID");
                            $query->execute([':accountID' => $accountID]);
                            $query = $db->prepare("UPDATE accounts SET balance = :balance WHERE accountID = :accountID");
                            $query->execute([':balance' => $account['balance']-$moderPrice, ':accountID' => $accountID]);
                            header ('Location: shop');
                        }
                    } else {
                        $query = $db->prepare("INSERT INTO roleassign (roleID, accountID) VALUES (4, :accountID)");
                        $query->execute([':accountID' => $accountID]);
                        $query = $db->prepare("UPDATE accounts SET balance = :balance WHERE accountID = :accountID");
                        $query->execute([':balance' => $account['balance']-$moderPrice, ':accountID' => $accountID]);
                        header ('Location: shop');
                    }
                } else {
                    header ('Location: shop');
                }
            } elseif($type == 'giveAdmin'){
                $id = $_POST['id'];
                $query = $db->prepare("SELECT count(*) FROM accounts WHERE accountID = :accountID");
                $query->execute([':accountID' => $id]);
                if($query->fetchColumn() > 0){
                    $query = $db->prepare("SELECT roleID FROM roleassign WHERE accountID = :accountID"); $query->execute([':accountID' => $id]); $roleID = $query->fetchColumn();
                    $query = $db->prepare("SELECT rolePrice FROM roles WHERE roleID = :roleID"); $query->execute([':roleID' => $roleID]); $rolePrice = $query->fetchColumn();
                    $query = $db->prepare("SELECT rolePrice FROM roles WHERE roleID = 3"); $query->execute(); $adminPrice = $query->fetchColumn() - $rolePrice; if($adminPrice < 0) $adminPrice = 0;
                    if($account['balance']-$adminPrice >= 0){
                        $query = $db->prepare("SELECT count(*) FROM roleassign WHERE accountID = :accountID");
                        $query->execute([':accountID' => $id]);
                        if($query->fetchColumn() > 0){
                            if($roleID <= 3){
                                header ('Location: shop');
                            } else {
                                $query = $db->prepare("UPDATE roleassign SET roleID = 3 WHERE accountID = :accountID");
                                $query->execute([':accountID' => $id]);
                                $query = $db->prepare("UPDATE accounts SET balance = :balance WHERE accountID = :accountID");
                                $query->execute([':balance' => $account['balance']-$adminPrice, ':accountID' => $accountID]);
                                header ('Location: shop');
                            }
                        } else {
                            $query = $db->prepare("INSERT INTO roleassign (roleID, accountID) VALUES (3, :accountID)");
                            $query->execute([':accountID' => $id]);
                            $query = $db->prepare("UPDATE accounts SET balance = :balance WHERE accountID = :accountID");
                            $query->execute([':balance' => $account['balance']-$adminPrice, ':accountID' => $accountID]);
                            header ('Location: shop');
                        }
                    } else {
                        header ('Location: shop');
                    }
                } else {
                    header ('Location: shop');
                }
            } elseif($type == 'buyAdmin'){
                if($account['balance']-$adminPrice >= 0){
                    $query = $db->prepare("SELECT count(*) FROM roleassign WHERE accountID = :accountID");
                    $query->execute([':accountID' => $accountID]);
                    if($query->fetchColumn() > 0){
                        if($roleID <= 3){
                            header ('Location: shop');
                        } else {
                            $query = $db->prepare("UPDATE roleassign SET roleID = 3 WHERE accountID = :accountID");
                            $query->execute([':accountID' => $accountID]);
                            $query = $db->prepare("UPDATE accounts SET balance = :balance WHERE accountID = :accountID");
                            $query->execute([':balance' => $account['balance']-$adminPrice, ':accountID' => $accountID]);
                            header ('Location: shop');
                        }
                    } else {
                        $query = $db->prepare("INSERT INTO roleassign (roleID, accountID) VALUES (3, :accountID)");
                        $query->execute([':accountID' => $accountID]);
                        $query = $db->prepare("UPDATE accounts SET balance = :balance WHERE accountID = :accountID");
                        $query->execute([':balance' => $account['balance']-$adminPrice, ':accountID' => $accountID]);
                        header ('Location: shop');
                    }
                } else {
                    header ('Location: shop');
                }
            } else{
                header ('Location: shop');
            }
        }
    } else { header ('Location: /'); }
?>

<!DOCTYPE html>
<html lang="ru">
    <head>
        <meta charset="UTF-8">
        <title>LSGD • Shop</title>
        <link rel="stylesheet" href="css/shop.css?<? include 'version.txt'; ?>">
        <link rel="shortcut icon" href="img/favicon.ico?v=1" type="image/x-icon">
    </head>
    <body>
        <div class="header">
            <div class="inner-header flexRow">
                <div class="logo"><a href="/">LSGD</a></div>
                <div class="user flexRow flexCenter">
                    <? if($log){ ?>
                    <div class="inner-user flexRow flexCenter padding" id="userName"><a href="account/id<? echo $accountID; ?>"><? echo $account['userName']; ?></a></div>
                    <div class="inner-user flexRow flexCenter padding" id="userBalance"><? echo $account['balance']; ?>&#8381;</div>
                    <div id="setting"><a href="account/setting">&#9881;</a></div>
                    <? } else { ?>
                    <a href="auth">Войти</a>
                    <? } ?>
                </div>
            </div>
        </div>
        <div class="container flexRow">
            <div class="shop">
                <div class="line"></div>
                <div class="inner-shop flexColumn padding">
                    <img src="img/shopVIP.png" alt="shopVIP.png">
                    <div class="title flexRow flexCenter">
                        <b>VIP</b>
                        <div class="flexRow flexCenter"><? echo $vipPrice; ?>&#8381;</div>
                    </div>
                    <p>• Префикс "VIP" •</p>
                    <p>• Копирование уровней без пароля •</p>
                    <p>• Отправка уровней на оценку - !rate &lt;кол-во звёзд (0-10)&gt; &lt;featured (0-1)&gt; •</p>
                    <div class="buy flexRow flexCenter">
                        <form class="flexRow" action="shop.php?type=giveVIP" method="post">
                            <input class="button flexRow flexCenter padding" id="give" type="submit" value="Подарить">
                            <input class="giveInput padding" type="text" name="id" placeholder="ID">
                        </form>
                        <? if($roleID <= 5 AND $roleID > 0){ ?>
                        <div class="sold flexRow flexCenter padding">Куплено</div>
                        <? } else {?>
                        <form action="shop.php?type=buyVIP&id=<? echo $accountID; ?>" method="post"><input class="button flexRow flexCenter padding" id="buy" type="submit" value="Купить"></form>
                        <? } ?>
                    </div>
                </div>
            </div>
            <div class="shop">
                <div class="line"></div>
                <div class="inner-shop flexColumn padding">
                    <img src="img/shopModerator.png" alt="shopModerator.png">
                    <div class="title flexRow flexCenter">
                        <b>Moderator</b>
                        <div class="flexRow flexCenter"><? echo $moderPrice; ?>&#8381;</div>
                    </div>
                    <p>• Префикс "Moderator" •</p>
                    <p>• Значок Moderator'а •</p>
                    <p>• Выдача сложности на уровень •</p>
                    <p>• Копирование уровней без пароля •</p>
                    <p>• Отправка уровней на оценку - !rate &lt;кол-во звёзд (0-10)&gt; &lt;featured (0-1)&gt; •</p>
                    <p>• Зелёный цвет текста комментариев •</p>
                    <div class="buy flexRow flexCenter">
                    <form class="flexRow" action="shop.php?type=giveModerator" method="post">
                            <input class="button flexRow flexCenter padding" id="give" type="submit" value="Подарить">
                            <input class="giveInput padding" type="text" name="id" placeholder="ID">
                        </form>
                        <? if($roleID <= 4 AND $roleID > 0){ ?>
                        <div class="sold flexRow flexCenter padding">Куплено</div>
                        <? } else { ?>
                        <form action="shop.php?type=buyModerator" method="post"><input class="button flexRow flexCenter padding" id="buy" type="submit" value="Купить"></form>
                        <? } ?>
                    </div>
                </div>
            </div>
            <div class="shop">
                <div class="line"></div>
                <div class="inner-shop flexColumn padding">
                    <img src="img/shopAdmin.png" alt="shopAdmin.png">
                    <div class="title flexRow flexCenter">
                        <b>Admin</b>
                        <div class="flexRow flexCenter"><? echo $adminPrice; ?>&#8381;</div>
                    </div>
                    <p>• Префикс "Admin" •</p>
                    <p>• Значок Elder Moderator'а •</p>
                    <p>• Выдача сложности на уровень •</p>
                    <p>• Выдача сложности на демон •</p>
                    <p>• Копирование уровней без пароля •</p>
                    <p>• Отправка уровней на оценку - !rate &lt;кол-во звёзд (0-10)&gt; &lt;featured (0-1)&gt; •</p>
                    <p>• Отправка уровней на Daily - !daily •</p>
                    <p>• Красный цвет текста комментариев •</p>
                    <div class="buy flexRow flexCenter">
                    <form class="flexRow" action="shop.php?type=giveAdmin" method="post">
                            <input class="button flexRow flexCenter padding" id="give" type="submit" value="Подарить">
                            <input class="giveInput padding" type="text" name="id" placeholder="ID">
                        </form>
                        <? if($roleID <= 3 AND $roleID > 0){ ?>
                        <div class="sold flexRow flexCenter padding">Куплено</div>
                        <? } else { ?>
                        <form action="shop.php?type=buyAdmin" method="post"><input class="button flexRow flexCenter padding" id="buy" type="submit" value="Купить"></form>
                        <? } ?>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
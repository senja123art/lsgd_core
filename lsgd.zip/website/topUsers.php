<?php
    require_once 'config.php';
    include $dir.'/incl/lib/connection.php';

    if(isset($_COOKIE['server'])){
        $cookie = unserialize($_COOKIE['server']);
        $accountID = $cookie['accountID'];
        $password = $cookie['password'];
        $query = $db->prepare("SELECT count(*) FROM accounts WHERE accountID = :accountID");
        $query->execute([':accountID' => $accountID]);
        if($query->fetchColumn() > 0){
            $query = $db->prepare("SELECT userName, password, isAdmin, balance FROM accounts WHERE accountID = :accountID");
            $query->execute([':accountID' => $accountID]);
            $query = $query->fetchAll();
            $account = $query[0];
            if(password_verify($password, $account['password'])){
                $log = true;
            } else {
                setcookie('server', null, time(), '/');
                header ('Location: /');
            }
        } else{
            setcookie('server', null, time(), '/');
            header ('Location: /');
        }
    } else { $log = false; }

    $query = $db->prepare("SELECT extID, userName, stars FROM users WHERE isRegistered = 1 ORDER BY stars DESC LIMIT 100");
    $query->execute(); $topStars = $query->fetchAll();
    $query = $db->prepare("SELECT extID, userName, demons FROM users WHERE isRegistered = 1 ORDER BY demons DESC LIMIT 100");
    $query->execute(); $topDemons = $query->fetchAll();
    $query = $db->prepare("SELECT extID, userName, userCoins FROM users WHERE isRegistered = 1 ORDER BY userCoins DESC LIMIT 100");
    $query->execute(); $topCoins = $query->fetchAll();
    $query = $db->prepare("SELECT extID, userName, creatorPoints FROM users WHERE isRegistered = 1 ORDER BY creatorPoints DESC LIMIT 100");
    $query->execute(); $topCreators = $query->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
    <head>
        <meta charset="UTF-8">
        <title>LSGD • Top users</title>
        <link rel="stylesheet" href="css/topUsers.css?<? include 'version.txt'; ?>">
        <link rel="shortcut icon" href="img/favicon.ico?v=1" type="image/x-icon">
    </head>
    <body>
        <div class="header">
            <div class="inner-header flexRow">
                <div class="logo"><a href="/">LSGD</a></div>
                <div class="user flexRow flexCenter">
                    <? if($log){ ?>
                    <div class="inner-user flexRow flexCenter padding" id="userName"><a href="account/id<? echo $accountID; ?>"><? echo $account['userName']; ?></a></div>
                    <div class="inner-user flexRow flexCenter padding" id="userBalance"><? echo $account['balance']; ?>&#8381;</div>
                    <div id="setting"><a href="account/setting">&#9881;</a></div>
                    <? } else { ?>
                    <a href="auth">Войти</a>
                    <? } ?>
                </div>
            </div>
        </div>
        <div class="container flexRow">
            <div class="top">
                <div class="line"></div>
                <div class="inner-top flexColumn padding">
                    <p>Топ игроков по звёздам</p>
                    <? for($i = 0; $i < count($topStars); $i++){ ?>
                    <div class="topUser flexRow flexCenter">
                        <p><? echo $i+1; ?>.</p>
                        <a href="account/id<? echo $topStars[$i]['extID']; ?>"><? echo $topStars[$i]['userName']; ?></a>
                        <p>- <? echo $topStars[$i]['stars']; ?></p>
                        <img src="img/stars.png" alt="stars.png">
                    </div>
                    <? } ?>
                </div>
            </div>
            <div class="top">
                <div class="line"></div>
                <div class="inner-top flexColumn padding">
                    <p>Топ игроков по демонам</p>
                    <? for($i = 0; $i < count($topDemons); $i++){ ?>
                    <div class="topUser flexRow flexCenter">
                        <p><? echo $i+1; ?>.</p>
                        <a href="account/id<? echo $topDemons[$i]['extID']; ?>"><? echo $topDemons[$i]['userName']; ?></a>
                        <p>- <? echo $topDemons[$i]['demons']; ?></p>
                        <img src="img/demons.png" alt="demons.png">
                    </div>
                    <? } ?>
                </div>
            </div>
            <div class="top">
                <div class="line"></div>
                <div class="inner-top flexColumn padding">
                    <p>Топ игроков по монеткам</p>
                    <? for($i = 0; $i < count($topCoins); $i++){ ?>
                    <div class="topUser flexRow flexCenter">
                        <p><? echo $i+1; ?>.</p>
                        <a href="account/id<? echo $topCoins[$i]['extID']; ?>"><? echo $topCoins[$i]['userName']; ?></a>
                        <p>- <? echo $topCoins[$i]['userCoins']; ?></p>
                        <img src="img/userCoins.png" alt="userCoins.png">
                    </div>
                    <? } ?>
                </div>
            </div>
            <div class="top">
                <div class="line"></div>
                <div class="inner-top flexColumn padding">
                    <p>Топ строителей</p>
                    <? for($i = 0; $i < count($topCreators); $i++){ ?>
                    <div class="topUser flexRow flexCenter">
                        <p><? echo $i+1; ?>.</p>
                        <a href="account/id<? echo $topCreators[$i]['extID']; ?>"><? echo $topCreators[$i]['userName']; ?></a>
                        <p>- <? echo $topCreators[$i]['creatorPoints']; ?></p>
                        <img src="img/creatorPoints.png" alt="creatorPoints.png">
                    </div>
                    <? } ?>
                </div>
            </div>
        </div>
    </body>
</html>
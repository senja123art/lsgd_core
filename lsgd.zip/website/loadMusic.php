<?php
    require_once 'config.php';
    include $dir.'/incl/lib/connection.php';

    if(isset($_COOKIE['server'])){
        $cookie = unserialize($_COOKIE['server']);
        $accountID = $cookie['accountID'];
        $password = $cookie['password'];
        $query = $db->prepare("SELECT count(*) FROM accounts WHERE accountID = :accountID");
        $query->execute([':accountID' => $accountID]);
        if($query->fetchColumn() > 0){
            $query = $db->prepare("SELECT userName, password, isAdmin, balance FROM accounts WHERE accountID = :accountID");
            $query->execute([':accountID' => $accountID]);
            $query = $query->fetchAll();
            $account = $query[0];
            if(password_verify($password, $account['password'])){
                if(!empty($_GET['type'])){
                    $type = htmlspecialchars($_GET['type']);
                    if($type == 'loadMusic'){
                        require_once $dir.'/config/songAdd.php';
                        $link = $_POST['link'];
                        $name = $_POST['name'];
                        $name = preg_replace("/[^A-Za-z0-9 ]/", '', $name);
                        $author = $_POST['author'];
                        $author = preg_replace("/[^A-Za-z0-9 ]/", '', $author);
                        if($link != '' AND $name != '' AND $author != ''){
                            $link = str_replace("www.dropbox.com", "dl.dropboxusercontent.com", $link);
                            if(filter_var($link, FILTER_VALIDATE_URL) == true){
                                $musicText = '';
                                $soundcloud = false;
                                if(strpos($link, 'soundcloud.com') !== false){
                                    $soundcloud = true;
                                    $songinfo = file_get_contents('https://api.soundcloud.com/resolve.json?url='.$link.'&client_id='.$api_key);
                                    $array = json_decode($songinfo);
                                    if($array->downloadable == true){
                                        $link = trim($array->download_url.'?client_id='.$api_key);
                                        $musicText .= 'Обработка музыки с SoundCloud "'.htmlspecialchars($name, ENT_QUOTES).'" by '.htmlspecialchars($author, ENT_QUOTES).' по ссылке '.htmlspecialchars($link, ENT_QUOTES).' <br>';
                                    } else {
                                        if(!$array->id){
                                            $musicText .= 'Эта музыка недоступна для скачивания и воспроизводства';
                                            header ('Location: loadMusic');
                                        }
                                        $link = trim('https://api.soundcloud.com/tracks/'.$array->id.'/stream?client_id='.$api_key);
                                        $musicText .= 'Эта музыка недоступна для скачивания, но я её попытаюсь добавить<br>';
                                    }
                                } else {
                                    $link = str_replace("?dl=0","",$link); $link = str_replace("?dl=1","",$link); $link = trim($link);
                                }
                                $musicInfo = curl_init($link);
                                curl_setopt($musicInfo, CURLOPT_RETURNTRANSFER, true);
                                curl_setopt($musicInfo, CURLOPT_HEADER, true);
                                curl_setopt($musicInfo, CURLOPT_NOBODY, true);
                                $data = curl_exec($musicInfo);
                                $size = curl_getinfo($musicInfo, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
                                curl_close($musicInfo);
                                $size = round($size / 1024 / 1024, 2);
                                $hash = "";
                                $query = $db->prepare("SELECT count(*) FROM songs WHERE download = :download");
                                $query->execute([':download' => $link]);	
                                $count = $query->fetchColumn();
                                if($count > 0){
                                    $query = $db->prepare("SELECT ID FROM songs WHERE download = :download");
                                    $query->execute([':download' => $link]);	
                                    $musicText .= 'Эта музыка уже загружена в базу данных. Её <b style="color: var(--white)">ID: '.$query->fetchColumn().'</b>';
                                } else {
                                    $query = $db->prepare("INSERT INTO songs (name, authorID, authorName, size, download, hash, reuploadID) VALUES (:name, 0, :author, :size, :download, :hash, :reuploadID)");
                                    $query->execute([':name' => $name, ':download' => $link, ':author' => $author, ':size' => $size, ':hash' => $hash, ':reuploadID' => $accountID]);
                                    $musicText .= 'Музыка успешно загружена. Её <b style="color: var(--white)">ID: '.$db->lastInsertId().'</b><hr>';
                                }
                            } else {
                                $musicText .= 'Неправильная ссылка для скачивания';
                            }
                        } else {
                            header ('Location: loadMusic');
                        }
                    } else {
                        header ('Location: loadMusic');
                    }
                } else{
                    // header ('Location: /');
                }
            } else {
                setcookie('server', null, time(), '/');
                header ('Location: /');
            }
        } else{
            setcookie('server', null, time(), '/');
            header ('Location: /');
        }
    } else { header ('Location: /'); }
?>

<!DOCTYPE html>
<html lang="ru">
    <head>
        <meta charset="UTF-8">
        <title>LSGD • Load music</title>
        <link rel="stylesheet" href="css/loadMusic.css?<? include 'version.txt'; ?>">
        <link rel="shortcut icon" href="img/favicon.ico?v=1" type="image/x-icon">
    </head>
    <body>
        <div class="header">
            <div class="inner-header flexRow">
                <div class="logo"><a href="/">LSGD</a></div>
                <div class="user flexRow flexCenter">
                    <div class="inner-user flexRow flexCenter padding" id="userName"><a href="account/id<? echo $accountID; ?>"><? echo $account['userName']; ?></a></div>
                    <div class="inner-user flexRow flexCenter padding" id="userBalance"><? echo $account['balance']; ?>&#8381;</div>
                    <div id="setting"><a href="account/setting">&#9881;</a></div>
                </div>
            </div>
        </div>
        <div class="container flexRow flexCenter">
            <div class="loadMusic">
                <div class="line"></div>
                <form class="inner-loadMusic flexColumn flexCenter padding" action="loadMusic.php?type=loadMusic" method="post">
                    <? if($type == 'loadMusic'){ ?>
                    <p id="musicText"><? echo $musicText; ?></p>
                    <? } else { ?>
                    <p>Загрузить музыку</p>
                    <input class="text" type="text" name="link" placeholder="Ссылка на музыку (Soundcloud или Dropbox)" required>
                    <input class="text" type="text" name="name" placeholder="Название музыки" required>
                    <input class="text" type="text" name="author" placeholder="Автор музыки" required>
                    <input class="button" type="submit" value="Загрузить">
                    <? } ?>
                </form>
            </div>
        </div>
    </body>
</html>
<?php
    require_once 'config.php';
    include $dir.'/incl/lib/connection.php';

    if(isset($_COOKIE['server'])){
        $cookie = unserialize($_COOKIE['server']);
        $accountID = $cookie['accountID'];
        $password = $cookie['password'];
        $query = $db->prepare("SELECT count(*) FROM accounts WHERE accountID = :accountID");
        $query->execute([':accountID' => $accountID]);
        if($query->fetchColumn() > 0){
            $query = $db->prepare("SELECT userName, password, isAdmin, balance FROM accounts WHERE accountID = :accountID");
            $query->execute([':accountID' => $accountID]);
            $query = $query->fetchAll();
            $account = $query[0];
            if(password_verify($password, $account['password'])){
                if($account['isAdmin'] == 1){
                    if(isset($_POST['submit'])){
                        $account = $_POST['account'];
                        $query = $db->prepare("SELECT count(*) FROM accounts WHERE userName = :account OR accountID = :account");
                        $query->execute([':account' => $account]);
                        if($query->fetchColumn() > 0){
                            $value = $_POST['value'];
                            $query = $db->prepare("UPDATE accounts SET balance = balance+:value WHERE userName = :account OR accountID = :account");
                            $query->execute([':value' => $value, ':account' => $account]);
                            header ('Location: /');
                        } else {
                            $out = 'Incorected <b>userName</b> or <b>accountID</b>. Try again.';
                        }
                    }
                } else {
                    header ('Location: /');
                }
            } else {
                setcookie('server', null, time(), '/');
                header ('Location: /');
            }
        } else{
            setcookie('server', null, time(), '/');
            header ('Location: /');
        }
    } else { header ('Location: /'); }
?>

<!DOCTYPE html>
<html lang="ru">
    <head>
        <meta charset="UTF-8">
        <title>LSGD • Add money</title>
        <link rel="shortcut icon" href="img/favicon.ico?v=1" type="image/x-icon">
    </head>
    <body>
        <? echo $out; ?>
        <form action="addMoney" method="post">
            <input type="text" name="account" placeholder="userName or accountID"></br>
            <input type="text" name="value" placeholder="value"></br>
            <input type="submit" name="submit">
        </form>
    </body>
</html>
<?php
    require_once 'config.php';
    include $dir.'/incl/lib/connection.php';

    if(isset($_COOKIE['server'])){
        $cookie = unserialize($_COOKIE['server']);
        $accountID = $cookie['accountID'];
        $password = $cookie['password'];
        $query = $db->prepare("SELECT count(*) FROM accounts WHERE accountID = :accountID");
        $query->execute([':accountID' => $accountID]);
        if($query->fetchColumn() > 0){
            $query = $db->prepare("SELECT userName, password, isAdmin, balance FROM accounts WHERE accountID = :accountID");
            $query->execute([':accountID' => $accountID]);
            $query = $query->fetchAll();
            $account = $query[0];
            if(password_verify($password, $account['password'])){
                $query = $db->prepare("SELECT roles.toolSuggestlist FROM roles INNER JOIN roleassign ON roles.roleID = roleassign.roleID WHERE roleassign.accountID = :accountID");
                $query->execute([':accountID' => $accountID]);
                if($query->fetchColumn() == 1){
                    $mod = true;
                } else {
                    $mod = false;
                }
                $log = true;
            } else {
                setcookie('server', null, time(), '/');
                header ('Location: /');
            }
        } else{
            setcookie('server', null, time(), '/');
            header ('Location: /');
        }

        $query = $db->prepare("SELECT DISTINCT levelID, rated, timestamp FROM suggestlevels ORDER BY timestamp DESC");
        $query->execute();
        $levels = $query->fetchAll();
    } else { header ('Location: /'); }
?>

<!DOCTYPE html>
<html lang="ru">
    <head>
        <meta charset="UTF-8">
        <title>LSGD • Sended levels</title>
        <link rel="stylesheet" href="css/sendLevels.css?<? include 'version.txt'; ?>">
        <link rel="shortcut icon" href="img/favicon.ico?v=1" type="image/x-icon">
    </head>
    <body>
        <div class="header">
            <div class="inner-header flexRow">
                <div class="logo"><a href="/">LSGD</a></div>
                <div class="user flexRow flexCenter">
                    <? if($log){ ?>
                    <div class="inner-user flexRow flexCenter padding" id="userName"><a href="account/id<? echo $accountID; ?>"><? echo $account['userName']; ?></a></div>
                    <div class="inner-user flexRow flexCenter padding" id="userBalance"><? echo $account['balance']; ?>&#8381;</div>
                    <div id="setting"><a href="account/setting">&#9881;</a></div>
                    <? } else { ?>
                    <a href="auth">Войти</a>
                    <? } ?>
                </div>
            </div>
        </div>
        <div class="container">
            <?php 
                ob_flush(); flush();
                foreach($levels as $level){
                    $query = $db->prepare("SELECT levelName, userName, extID, starDifficulty, starAuto, starDemon, starDemonDiff, starStars FROM levels WHERE levelID = :levelID");
                    $query->execute([':levelID' => $level['levelID']]);
                    $query = $query->fetchAll(); $levelInfo = $query[0];
                    $query = $db->prepare("SELECT count(*) FROM roleassign JOIN suggest ON roleassign.accountID = suggest.suggestBy WHERE roleassign.roleID = 5 AND suggest.suggestLevelId = :suggestLevelId GROUP BY roleassign.roleID");
                    $query->execute([':suggestLevelId' => $level['levelID']]);
                    $vipCount = $query->fetchColumn();
                    $query = $db->prepare("SELECT count(*) FROM roleassign JOIN suggest ON roleassign.accountID = suggest.suggestBy WHERE roleassign.roleID = 4 AND suggest.suggestLevelId = :suggestLevelId GROUP BY roleassign.roleID");
                    $query->execute([':suggestLevelId' => $level['levelID']]);
                    $moderCount = $query->fetchColumn();
                    $query = $db->prepare("SELECT count(*) FROM roleassign JOIN suggest ON roleassign.accountID = suggest.suggestBy WHERE roleassign.roleID = 3 AND suggest.suggestLevelId = :suggestLevelId GROUP BY roleassign.roleID");
                    $query->execute([':suggestLevelId' => $level['levelID']]);
                    $adminCount = $query->fetchColumn();
                    $query = $db->prepare("SELECT count(*) FROM roleassign JOIN suggest ON roleassign.accountID = suggest.suggestBy WHERE roleassign.roleID = 2 AND suggest.suggestLevelId = :suggestLevelId GROUP BY roleassign.roleID");
                    $query->execute([':suggestLevelId' => $level['levelID']]);
                    $helperCount = $query->fetchColumn();
                    $query = $db->prepare("SELECT count(*) FROM roleassign JOIN suggest ON roleassign.accountID = suggest.suggestBy WHERE roleassign.roleID = 1 AND suggest.suggestLevelId = :suggestLevelId GROUP BY roleassign.roleID");
                    $query->execute([':suggestLevelId' => $level['levelID']]);
                    $ownerCount = $query->fetchColumn();
            ?>
            <div class="level">
                <div class="line"></div>
                <div class="inner-level flexRow flexCenter padding">
                    <div class="rate flexColumn flexCenter">
                        <?php 
                            if($levelInfo['starDifficulty'] == 10){
                                echo '<img id="rate" src="img/levelIcons/easy.png" alt="easy.png">';
                            } elseif($levelInfo['starDifficulty'] == 20){
                                echo '<img id="rate" src="img/levelIcons/normal.png" alt="normal.png">';
                            } elseif($levelInfo['starDifficulty'] == 30){
                                echo '<img id="rate" src="img/levelIcons/hard.png" alt="hard.png">';
                            } elseif($levelInfo['starDifficulty'] == 40){
                                echo '<img id="rate" src="img/levelIcons/harder.png" alt="harder.png">';
                            } elseif($levelInfo['starDifficulty'] == 50){
                                if($levelInfo['starAuto'] == 1){
                                    echo '<img id="rate" src="img/levelIcons/auto.png" alt="auto.png">';
                                } elseif($levelInfo['starDemon'] == 1){
                                    if($levelInfo['starDemonDiff'] == 3){
                                        echo '<img id="rate" src="img/levelIcons/easyDemon.png" alt="easyDemon.png">';
                                    } elseif($levelInfo['starDemonDiff'] == 4){
                                        echo '<img id="rate" src="img/levelIcons/mediumDemon.png" alt="mediumDemon.png">';
                                    } elseif($levelInfo['starDemonDiff'] == 5){
                                        echo '<img id="rate" src="img/levelIcons/insaneDemon.png" alt="insaneDemon.png">';
                                    } elseif($levelInfo['starDemonDiff'] == 6){
                                        echo '<img id="rate" src="img/levelIcons/extremeDemon.png" alt="extremeDemon.png">';
                                    } else {
                                        echo '<img id="rate" src="img/levelIcons/hardDemon.png" alt="hardDemon.png">';
                                    }
                                } else {
                                    echo '<img id="rate" src="img/levelIcons/insane.png" alt="insane.png">';
                                }
                            } else {
                                echo '<img id="rate" src="img/levelIcons/na.png" alt="na.png">';
                            }

                            if($levelInfo['starStars'] > 0){
                        ?>
                        <div class="stars flexRow flexCenter">
                            <p><? echo $levelInfo['starStars']; ?></p>
                            <img src="img/stars.png" alt="stars.png">
                        </div>
                        <? } ?>
                    </div>
                    <div class="levelInfo">
                        <b><? echo $levelInfo['levelName']; ?></b>
                        <p>Автор: <a href="account/id<? echo $levelInfo['extID']; ?>"><? echo $levelInfo['userName']; ?></a></p>
                    </div>
                    <div class="modRates flexRow">
                        <? if($vipCount > 0){ ?>
                        <div class="flexRow flexCenter" id="vip"><? echo $vipCount; ?></div>
                        <? } if($moderCount > 0){ ?>
                        <div class="flexRow flexCenter" id="moderator"><? echo $moderCount; ?></div>
                        <? } if($adminCount > 0){ ?>
                        <div class="flexRow flexCenter" id="administrator"><? echo $adminCount; ?></div>
                        <? } if($helperCount > 0){ ?>
                        <div class="flexRow flexCenter" id="helper"><? echo $helperCount; ?></div>
                        <? } if($ownerCount > 0){ ?>
                        <div class="flexRow flexCenter" id="owner"><? echo $ownerCount; ?></div>
                        <? } ?>
                    </div>
                    <? if($level['rated'] == 1){ ?>
                    <img id="rated" src="img/confirm.png" alt="confirm.png">
                    <? } elseif($level['rated'] == -1){ ?>
                    <img id="rated" src="img/decline.png" alt="decline.png">
                    <? } else { if($mod){ ?>
                    <a href="rateLevel/id<? echo $level['levelID']; ?>"><img id="rateLevel" src="img/rateButton.png" alt="rateButton.png"></a>
                    <? }} ?>
                </div>
            </div>
            <? } ?>
        </div>
    </body>
</html>
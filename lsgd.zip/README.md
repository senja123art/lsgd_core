"# lsgd_core" 

<?php
include "incl/levelpacks/getGJGauntlets.php";
?>
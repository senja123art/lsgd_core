<?php
include "../incl/lib/connection.php";
require_once "../incl/lib/exploitPatch.php";
$ep = new exploitPatch();
if($_POST["userName"] != ""){
	//here im getting all the data
	$userName = $ep->remove($_POST["userName"]);
	$password = $ep->remove($_POST["password"]);
	$email = $ep->remove($_POST["email"]);
	$secret = "";
	//checking if name is taken
	$query2 = $db->prepare("SELECT count(*) FROM accounts WHERE userName LIKE :userName OR email LIKE :email");
	$query2->execute([':userName' => $userName, ':email' => $email]);
	$regusrs = $query2->fetchColumn();
	if($regusrs > 0) {
		echo "-2";
	}else{
		if(isset($_SERVER['HTTP_CF_CONNECTING_IP'])){ $ip = $_SERVER['HTTP_CF_CONNECTING_IP']; } 
		elseif(isset($_SERVER['HTTP_X_FORWARDED_FOR']) && ipInRange::ipv4_in_range($_SERVER['REMOTE_ADDR'], '127.0.0.0/8')){ $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; }
		else { $ip = $_SERVER['REMOTE_ADDR']; }
		$query = $db->prepare("SELECT count(*) FROM actions WHERE type = 1337 AND value2 LIKE :ip");
		$query->execute([':ip' => $ip]);
		$count = $query->fetchColumn();
		if($count < 3){
			$hashpass = password_hash($password, PASSWORD_DEFAULT);
			$query = $db->prepare("INSERT INTO accounts (userName, password, email, secret, saveData, registerDate, saveKey)
			VALUES (:userName, :password, :email, :secret, '', :time, '')");
			$query->execute([':userName' => $userName, ':password' => $hashpass, ':email' => $email, ':secret' => $secret, ':time' => time()]);
			$query = $db->prepare("INSERT INTO actions (type, timestamp, value2) VALUES (1337, :time, :value2)");
			$query->execute([':value2' => $ip, ':time' => time()]);
			echo "1";
		} else {
			echo "-2";
		}
	}
}
?>
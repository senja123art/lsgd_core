<?php
include "incl/relationships/getGJFriendRequests.php";
?>
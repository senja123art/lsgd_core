<?php
//error_reporting(0);
chdir(dirname(__FILE__));
include "../lib/connection.php";
require_once "../lib/GJPCheck.php";
require_once "../lib/exploitPatch.php";
$ep = new exploitPatch();
require_once "../lib/mainLib.php";
$gs = new mainLib();
$gjp = $ep->remove($_POST["gjp"]);
$stars = $ep->remove($_POST["stars"]);
$feature = $ep->remove($_POST["feature"]);
$levelID = $ep->remove($_POST["levelID"]);
$accountID = $ep->remove($_POST["accountID"]);
if($accountID != "" AND $gjp != ""){
	$GJPCheck = new GJPCheck();
	$gjpresult = $GJPCheck->check($gjp,$accountID);
	if($gjpresult == 1){
		$auto = 0; $demon = 0;
		if($stars == 1 OR $stars >= 8){
			$difficulty = 50;
			if($stars == 1){
				$auto = 1;
			} elseif($stars >= 10){
				$demon = 1;
			}
		} elseif($stars == 2){
			$difficulty = 10;
		} elseif($stars == 3){
			$difficulty = 20;
		} elseif($stars == 4 OR $stars == 5){
			$difficulty = 30;
		} elseif($stars == 6 OR $stars == 7){
			$difficulty = 40;
		} else {
			echo -2;
		}
		if($gs->checkPermission($accountID, "actionSuggestRating")){
			$query = $db->prepare("SELECT count(*) FROM suggestlevels WHERE levelID = :levelID");
			$query->execute([':levelID' => $levelID]);
			if($query->fetchColumn() == 0){
				$query = $db->prepare("INSERT INTO suggestlevels (levelID, timestamp) VALUES (:levelID, :time)");
				$query->execute([':levelID' => $levelID, ':time' => time()]);
			}
			$query = $db->prepare("SELECT count(*) FROM suggest WHERE suggestLevelId = :levelID AND suggestBy = :accountID");
			$query->execute([':levelID' => $levelID, ':accountID' => $accountID]);
			if($query->fetchColumn() == 0){
				$query = $db->prepare("INSERT INTO suggest (suggestBy, suggestLevelId, suggestDifficulty, suggestStars, suggestAuto, suggestDemon, suggestFeatured, timestamp) VALUES (:accountID, :levelID, :difficulty, :stars, :auto, :demon, :feature, :time)");
				$query->execute([':accountID' => $accountID, ':levelID' => $levelID, ':difficulty' => $difficulty, ':stars' => $stars, ':auto' => $auto, ':demon' => $demon, ':feature' => $feature, ':time' => time()]);
			}
			if($gs->checkPermission($accountID, "actionRateStars")){
				$query = $db->prepare("SELECT levelLength FROM levels WHERE levelID = :levelID");
				$query->execute([':levelID' => $levelID]);
				if($query->fetchColumn() >= 2){
					$query = $db->prepare("UPDATE levels SET starDifficulty = :difficulty, starStars = :stars, starAuto = :auto, starDemon = :demon, starFeatured = :feature, starCoins = 1 WHERE levelID = :levelID");
					$query->execute([':difficulty' => $difficulty, ':stars' => $stars, ':auto' => $auto, ':demon' => $demon, ':feature' => $feature, ':levelID' => $levelID]);
					$query = $db->prepare("UPDATE suggestlevels SET rated = 1 WHERE levelID = :levelID");
					$query->execute([':levelID' => $levelID]);
				}
			}
			echo 1;
		} else {
			echo -2;
		}
	}else{
		echo -2;
	}
}else{
	echo -2;
}
?>
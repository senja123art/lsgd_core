<?php
chdir(dirname(__FILE__));
include "../lib/connection.php";
require_once "../lib/GJPCheck.php";
require_once "../lib/exploitPatch.php";
$ep = new exploitPatch();
require_once "../lib/mainLib.php";
$gs = new mainLib();
$gjp = $ep->remove($_POST["gjp"]);
$stars = $ep->remove($_POST["stars"]);
if($stars < 1 OR $stars > 10){ echo -1; exit(); }
$levelID = $ep->remove($_POST["levelID"]);
$accountID = $ep->remove($_POST["accountID"]);
if($accountID != "" AND $gjp != ""){
	$GJPCheck = new GJPCheck();
	$gjpresult = $GJPCheck->check($gjp,$accountID);
	if($gjpresult == 1){
		$permState = $gs->checkPermission($accountID, "actionRateDifficulty");
		if($permState){
			$auto = 0; $demon = 0;
			if($stars == 1 OR $stars >= 8){
				$difficulty = 50;
				if($stars == 1){
					$auto = 1;
				} elseif($stars >= 10){
					$demon = 1;
				}
			} elseif($stars == 2){
				$difficulty = 10;
			} elseif($stars == 3){
				$difficulty = 20;
			} elseif($stars == 4 OR $stars == 5){
				$difficulty = 30;
			} elseif($stars == 6 OR $stars == 7){
				$difficulty = 40;
			} else {
				echo -1;
			}
			$query = $db->prepare("UPDATE levels SET starDifficulty = :difficulty WHERE levelID = :levelID");
			$query->execute([':difficulty' => $difficulty, ':levelID' => $levelID]);
			$suggest = $gs->checkPermission($accountID, "actionSuggestRating");
			if($suggest){
				$query = $db->prepare("SELECT count(*) FROM suggestlevels WHERE levelID = :levelID");
				$query->execute([':levelID' => $levelID]);
				if($query->fetchColumn() == 0){
					$query = $db->prepare("INSERT INTO suggestlevels (levelID, timestamp) VALUES (:levelID, :time)");
					$query->execute([':levelID' => $levelID, ':time' => time()]);
				}
				$query = $db->prepare("SELECT count(*) FROM suggest WHERE suggestLevelId = :levelID AND suggestBy = :accountID");
				$query->execute([':levelID' => $levelID, ':accountID' => $accountID]);
				if($query->fetchColumn() == 0){
					$query = $db->prepare("INSERT INTO suggest (suggestBy, suggestLevelId, suggestDifficulty, suggestStars, suggestAuto, suggestDemon, timestamp) VALUES (:accountID, :levelID, :difficulty, :stars, :auto, :demon, :time)");
					$query->execute([':accountID' => $accountID, ':levelID' => $levelID, ':difficulty' => $difficulty, ':stars' => $stars, ':auto' => $auto, ':demon' => $demon, ':time' => time()]);
				}
			}
		}else{
			$query = $db->prepare("INSERT INTO actions (type, value, timestamp, value3, account) VALUES (1340, :levelID, :time, :stars, :accountID)");
			$query->execute([':levelID' => $levelID, ':time' => time(), ':stars' => $stars, ':accountID' => $accountID]);
			$query = $db->prepare("SELECT count(*) FROM actions WHERE type = 1340 AND value = :levelID AND value3 > 0");
			$query->execute([':levelID' => $levelID]);
			if($query->fetchColumn() >= 10){
				$query = $db->prepare("SELECT value3 FROM actions WHERE type = 1340 AND value = :levelID AND value3 > 0");
				$query->execute([':levelID' => $levelID]);
				$actions = $query->fetchAll();
				$stars = 0;
				foreach($actions as $addStars){
					$stars += $addStars;
				}
				$stars = $stars/count($actions); $stars = round($stars);
				$auto = 0; $demon = 0;
				if($stars == 1 OR $stars >= 8){
					$difficulty = 50;
					if($stars == 1){
						$auto = 1;
					} elseif($stars >= 10){
						$demon = 1;
					}
				} elseif($stars == 2){
					$difficulty = 10;
				} elseif($stars == 3){
					$difficulty = 50;
				} elseif($stars == 4 OR $stars == 5){
					$difficulty = 30;
				} elseif($stars == 6 OR $stars == 7){
					$difficulty = 40;
				} else {
					echo -1;
				}
				$query = $db->prepare("UPDATE levels SET starDifficulty = :difficulty WHERE levelID = :levelID");
				$query->execute([':difficulty' => $difficulty, ':levelID' => $levelID]);
			}
		}
		
		echo 1;
	}else{echo -1;}
}else{echo -1;}
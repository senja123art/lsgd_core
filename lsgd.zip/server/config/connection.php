<?php
$servername = "localhost";
$username = "h6890863_lsgd";
$password = "x1pFbsPh";
$dbname = "h6890863_lsgd";
?>